Deathtrap Tile Puzzle
Group 4

Our project is a game about a puzzle from "Uncharted " games series, called ( Deathtrap Tile Puzzle ) 

It's contains two type of tiles : safes and traps , Start frame explains the puzzle as follows: there's three shapes : the ship , the sun and the sword, each shape have its own places for the traps , the player should understand that and continue to Deathtrap frame and start the game . 

1 . Interface frame :
- Contains greeting.
- press begin to continue to Start frame .

2 . Start frame : 
- contains the explanation for the puzzle 
- press Start to continue to Deathtrap frame .


3 . Deathtrap : 
- has the game's board . 
- the player should select all the save tiles to win then it's continue to Escape frame ( win ) .
- if the player chooses trap he lost the game and continue to Reset frame .

4 . Escape frame :
- continue two buttons: replay and Exit .

5 . Reset frame :
- continue two buttons: replay and Exit .
 